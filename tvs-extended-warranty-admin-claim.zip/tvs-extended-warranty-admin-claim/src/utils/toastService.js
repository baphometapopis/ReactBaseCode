import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export const showSuccessToast = (message, options = {}) => {
    console.log('dsdsdsdd')
  toast.success(message, {
    position: "bottom-right",
        autoClose: false,
        theme:'colored',
  
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
  });
};

export const showErrorToast = (message, options = {}) => {
  toast.error(message, {
    position: "bottom-right",
        autoClose: false,
        // autoClose: 3000,
        theme:'colored',
  
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
  });
};
