import React from 'react'

export const NotFoundPage = () => {
  return (
    <div>NotFoundPage</div>
  )
}
