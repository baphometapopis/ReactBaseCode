import React from 'react'

const ClaimListPage = () => {
  return (
    <div>
      This is claim list page 
    </div>
  )
}

export default ClaimListPage
