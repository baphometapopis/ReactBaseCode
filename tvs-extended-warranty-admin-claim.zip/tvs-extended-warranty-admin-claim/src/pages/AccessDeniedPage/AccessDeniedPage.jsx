import React from 'react'

export const AccessDeniedPage = () => {
  return (
    <div>AccessDeniedPage</div>
  )
}
