import React from 'react'

const DashboardPage = () => {
  return (
    <div>
      This is Dashboard
    </div>
  )
}

export default DashboardPage
