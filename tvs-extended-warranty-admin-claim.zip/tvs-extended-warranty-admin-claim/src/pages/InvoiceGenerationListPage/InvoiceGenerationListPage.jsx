import React from 'react'

export const InvoiceGenerationListPage = () => {
  return (
    <div>InvoiceGenerationListPage</div>
  )
}
