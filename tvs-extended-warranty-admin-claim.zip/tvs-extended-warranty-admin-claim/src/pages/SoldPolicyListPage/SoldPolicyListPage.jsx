import React from 'react'

export const SoldPolicyListPage = () => {
  return (
    <div>SoldPolicyListPage</div>
  )
}
