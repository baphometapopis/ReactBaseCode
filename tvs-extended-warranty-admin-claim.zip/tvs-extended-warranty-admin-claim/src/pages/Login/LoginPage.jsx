import React, { useState } from 'react';
import { setUserSession } from '../../utils/auth';
import { showErrorToast, showSuccessToast } from '../../utils/toastService';
import './LoginPage.css';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    console.log('dsdsdsdd')


    // Dummy authentication API call
    const response = {
      status: true,
      message: 'Login successful',
      data: {
        token: '1026|0ogmbq92OwcHf8H16rOWPwoGLf7GRBMyTq2Oghco1fcb1134',
        user_details: {
          id: 4,
          first_name: 'Admin',
          last_name: 'Master',
          address: 'mumbai',
          email_id: 'admin_master@opnrsa.com',
          mobile_no: '8898188910',
          admin_role_id: 1,
          admin_role: 'admin_master',
          role_type: 'admin',
          is_active: 1,
          dealer_name: 'Admin',
        },
        sidebarlist:[
          {label: 'Dashboard', icon: 'DashboardIcon', path: '/' },
          { label: 'Sold Policy List', icon: 'SoldPolicyList', path: '/sold-policy' },
          { label: 'Claim List', icon: 'ClaimList', path: '/claims' },
          { label: 'Reports', icon: 'Report', path: '/reports' },
          { label: 'Invoices', icon: 'Invoices', path: '/invoices' },
      
      
        ]
      },
    };

    if (response.status) {
    showSuccessToast('successfully Logge In')

    setTimeout(() => {
      window.location.reload();
    }, 500 );       
      setUserSession(response);
    } else {
showErrorToast('login failed')
    }
  };

  return (
    <div className="login-page">
      <div className="login-page-container">
        <h1>Login</h1>
        <img src={''} className="logo" alt="Company LOGO" />
        <form className="form" onSubmit={handleLogin}>
          <div className="input-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="example@gmail.com"
            />
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="**********"
            />
          </div>
          <button className="primary" type="submit">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
