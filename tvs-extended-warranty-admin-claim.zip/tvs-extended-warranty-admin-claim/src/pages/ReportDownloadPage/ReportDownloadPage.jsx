import React from 'react'

const ReportDownloadPage = () => {
  return (
    <div>
      Thsi si Report Page
    </div>
  )
}

export default ReportDownloadPage
