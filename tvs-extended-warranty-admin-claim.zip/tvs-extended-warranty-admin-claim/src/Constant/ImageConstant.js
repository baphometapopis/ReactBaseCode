import DashboardIcon from '../assets/SidebartIcons/dashboard.png'
import ClaimList from '../assets/SidebartIcons/claim-list.png'
import SoldPolicyList from '../assets/SidebartIcons/sold-policy.png'

import Invoices from '../assets/SidebartIcons/invoices.png'
import Report from '../assets/SidebartIcons/report.png'



import Logout from '../assets/SidebartIcons/logout.png'
import Logo from '../assets/SidebartIcons/logout.png'
import Menu from '../assets/SidebartIcons/logout.png'




export {DashboardIcon,Logout,Logo,Menu,ClaimList,Invoices,Report,SoldPolicyList}