import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  DashboardIcon,
  ClaimList,
  SoldPolicyList,
  Invoices,
  Report,
  Logout,
  Logo,
  Menu
} from '../../Constant/ImageConstant';
import { getUserSession } from '../../utils/auth';
import './SideBar.css';

const iconMap = {
  DashboardIcon,
  ClaimList,
  SoldPolicyList,
  Invoices,
  Report,
  Logout,
  Logo,
  Menu
};

const Sidebar = ({ isOpen }) => {
  const navigate = useNavigate();
  const [menuItems, setMenuItems] = useState([]);

  useEffect(() => {
    const userdata = getUserSession();
    if (userdata) {
      console.log(userdata?.data);
      setMenuItems(userdata?.data?.sidebarlist);
    }
  }, []);

  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <ul className="sidebar-menu">
        {menuItems?.map((item, index) => (
          
          <li key={index} className="menu-item" onClick={() => navigate(item.path)}>
            {console.log(item.icon)}
            <img src={iconMap[item.icon]} alt={item.label} className="menu-icon" />
            {item.label}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;
